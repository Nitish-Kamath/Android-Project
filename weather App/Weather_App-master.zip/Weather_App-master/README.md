# Weather_App
It is an android app made by using kotlin and android studio for api I use open weather api.
